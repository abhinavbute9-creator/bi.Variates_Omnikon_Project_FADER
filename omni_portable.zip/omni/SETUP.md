# FADER — Setup Guide

## Backend (FastAPI)

    cd backend
    python3 -m venv venv
    source venv/bin/activate          # Windows: venv\Scripts\activate
    pip install -r requirements.txt
    cp .env.example .env
    # Edit .env: set DATABASE_URL=sqlite:///./fader.db  (unless you run Postgres)
    alembic upgrade head
    uvicorn app.main:app --reload --port 8000

Test at: http://127.0.0.1:8000/docs

## Flutter app

    cd fader_app
    flutter pub get
    flutter run -d chrome -t lib/second_main.dart

Notes:
- `lib/main.dart` is an earlier/simpler version (no live map).
- `lib/second_main.dart` is the current version with the real map + backend wiring via `lib/services/api_service.dart`.
- On an Android emulator, the backend URL auto-switches to `10.0.2.2` (see `ApiConfig` in `api_service.dart`). On a real phone, replace it with your PC's LAN IP.
- Backend defaults to a local SQLite database and simulated weather/routing data — no API keys required to run the demo. Add `MAPBOX_ACCESS_TOKEN` / `WEATHER_API_KEY` to `.env` for live data.
